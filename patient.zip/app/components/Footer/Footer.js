import React from 'react';
import './style.scss';

const Footer = () => (
  <footer>
    <section>&nbsp;</section>
  </footer>
);

export default Footer;
