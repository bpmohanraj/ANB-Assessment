/*
 * Billing Page
 *
 * List all the bill details
 */
import React from 'react';
import { Helmet } from 'react-helmet';
import './style.scss';
import DatePicker from 'react-datepicker';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faLock } from '@fortawesome/free-solid-svg-icons';
import toastr from 'toastr';
import { BILLING_DATA } from './constants';
import 'toastr/build/toastr.min.css';

export default class BillingPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      expiryDate: new Date(),
      payableAmount: 0,
      cvc: '',
      mode: '',
      cardName: '',
      cardNumber: '',
      data: []
    };
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange = (value, field) => {
    this.setState({ [field]: value });
  }

  saveHandler = () => {
    const { payableAmount, balanceAmount } = this.state;
    let { data } = this.state;
    if (data.length === 0) {
      data = Object.keys(BILLING_DATA).map((i) => BILLING_DATA[i]);
    }
    const { id } = this.props.match.params;
    if (data[id].previousTransaction.length === 2 && payableAmount !== data[id].balanceAmount) {
      toastr.error('Amount should be match with pending due.', 'Invalid!');
    } else if (data[id].previousTransaction.length <= 2 && ((payableAmount / balanceAmount) * 100) < 20) {
      toastr.error('Minimum amount should be 20% of the pending due.', 'Invalid!');
    }
  }

  render() {
    const {
      expiryDate, payableAmount, cvc, mode, cardName, cardNumber
    } = this.state;
    const { id } = this.props.match.params;
    let { data } = this.state;
    if (data.length === 0) {
      data = Object.keys(BILLING_DATA).map((i) => BILLING_DATA[i]);
    }
    return (
      <div className="billing-page">
        <Helmet>
          <title>Billing Page</title>
          <meta
            name="description"
            content="Billing page of Patient's Inventory application"
          />
        </Helmet>
        <h1>Patient Billing</h1>
        <div className="row">
          <div className="col">
            <label className="label-head-text">
              Current Billing Status
            </label>
          </div>
          <div className="col">
            <label className="label-head-text">
              Previous Transactions
            </label>
          </div>
        </div>
        <div className="row">
          <div className="col-4">
            <div className="row">
              <div className="col-6">
                <label className="label-text">
                  Patient Name
                </label>
              </div>
              <div className="col">
                <label className="label-text">
                  {data[id].patientName}
                </label>
              </div>
            </div>
            <div className="row">
              <div className="col-6">
                <label className="label-text">
                  Patient ID
                </label>
              </div>
              <div className="col">
                <label className="label-text">
                  {data[id].patientId}
                </label>
              </div>
            </div>
            <div className="row">
              <div className="col-6">
                <label className="label-text">
                  Age/Gender
                </label>
              </div>
              <div className="col">
                <label className="label-text">
                  {data[id].age}/{data[id].gender}
                </label>
              </div>
            </div>
            <div className="row">
              <div className="col-6">
                <label className="label-text">
                  Total Amount
                </label>
              </div>
              <div className="col">
                <label className="label-text">
                  {data[id].totalAmount} INR
                </label>
              </div>
            </div>
            <div className="row">
              <div className="col-6">
                <label className="label-text">
                  Discount
                </label>
              </div>
              <div className="col">
                <label className="label-text">
                  {data[id].discount} INR
                </label>
              </div>
            </div>
            <div className="row">
              <div className="col-6">
                <label className="label-text">
                  Paid Amount
                </label>
              </div>
              <div className="col">
                <label className="label-text">
                  {data[id].paidAmount} INR
                </label>
              </div>
            </div>
            <div className="row">
              <div className="col-6">
                <label className="label-text">
                  Balance
                </label>
              </div>
              <div className="col">
                <label className="label-text">
                  {data[id].balanceAmount} INR
                </label>
              </div>
            </div>
          </div>
          <div className="col">
            <table className="table table-hover table-sm">
              <thead>
                <tr className="table-primary">
                  <th scope="col">#</th>
                  <th scope="col">Date</th>
                  <th scope="col">Paid Amount</th>
                  <th scope="col">Payment Mode</th>
                </tr>
              </thead>
              <tbody>
                {data[id].previousTransaction.length > 0 && data[id].previousTransaction.map((transaction, index) => (
                  <tr key={index}>
                    <th scope="row">{index + 1}</th>
                    <td>{transaction.date}</td>
                    <td>{transaction.paidAmount}</td>
                    <td>{transaction.mode}</td>
                  </tr>
                ))}

                {data[id].previousTransaction.length === 0
                  && (
                    <tr>
                      <th scope="row" colSpan="4" style={{ textAlign: 'center' }}>No Record Found!</th>
                    </tr>
                  )
                }
              </tbody>
            </table>
          </div>
        </div>
        <div className="row">
          <div className="col-2">
            <label className="label-text">
              Payable Amount
            </label>
          </div>
          <div className="col-4">
            <input type="number" className="form-control medium-input" value={payableAmount} onChange={(e) => this.handleChange(e.target.value, 'payableAmount')} />
          </div>
          <div className="col-6">&nbsp;</div>
        </div>
        <div className="row">
          <div className="col-2">
            <label className="label-text">
              Payment Mode
            </label>
          </div>
          <div className="col">
            <select className="form-control select-input-sm" id="paymentMode" value={mode} onChange={(e) => this.handleChange(e.target.value, 'mode')}>
              <option value="Card">Card</option>
              <option value="Cash">Cash</option>
            </select>
          </div>
          <div className="col-6">&nbsp;</div>
        </div>
        <div className="row">
          <div className="col-6">
            <input type="text" className="form-control medium-input" placeholder="Card Holder's Name" value={cardName} onChange={(e) => this.handleChange(e.target.value, 'cardName')} />
          </div>
        </div>
        <div className="row row-margin-top">
          <div className="col-6">
            <input type="number" className="form-control medium-input" placeholder="Card Number" value={cardNumber} onChange={(e) => this.handleChange(e.target.value, 'cardNumber')} />
          </div>
        </div>
        <div className="row">
          <div className="col-auto">
            <label className="label-text">
              Expiry
            </label>
          </div>
        </div>
        <div className="row">
          <div className="col-2">
            <DatePicker id="expiryDate" className="form-control custom-input" selected={expiryDate} dateFormat="MM/yyyy" onChange={(e) => this.handleChange(e.target.value, 'expiryDate')} />
          </div>
          <div className="col-auto">
            <input type="number" className="form-control" placeholder="CVC" value={cvc} onChange={(e) => this.handleChange(e.target.value, 'cvc')} />
          </div>
          <div className="col-auto">
            <label className="label-text">
              <FontAwesomeIcon icon={faLock} /> 128-bit secured
            </label>
          </div>
        </div>
        <div className="row">
          <div className="col align-center">
            <button className="btn btn-primary save-btn" type="button" onClick={this.saveHandler}>Save</button>
          </div>
        </div>
      </div>
    );
  }
}
