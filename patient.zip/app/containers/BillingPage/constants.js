/*
 * AppConstants
 * Each action has a corresponding type, which the reducer knows and picks up on.
 * To avoid weird typos between the reducer and the actions, we save them as
 * constants here. We prefix them with 'yourproject/YourComponent' so we avoid
 * reducers accidentally picking up actions they shouldn't.
 *
 * Follow this format:
 * export const YOUR_ACTION_CONSTANT = 'yourproject/YourContainer/YOUR_ACTION_CONSTANT';
 */

export const BILLING_DATA = [
  {
    patientName: 'Hari Haran',
    patientId: 'ADY12004',
    age: 27,
    gender: 'Male',
    totalAmount: 370,
    discount: 10,
    paidAmount: 130,
    balanceAmount: 230,
    previousTransaction: [
      { date: '3rd Feb 2020', paidAmount: 25, mode: 'Card' },
      { date: '6th Feb 2020', paidAmount: 105, mode: 'Card' }
    ]
  }
];
