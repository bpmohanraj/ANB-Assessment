export { default } from './BillingPage';
