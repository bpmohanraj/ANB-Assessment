/*
 * Save Appointment Page
 *
 * Get the appointment details
 */
import React from 'react';
import { Helmet } from 'react-helmet';
import './style.scss';
import DatePicker from 'react-datepicker';
import { Typeahead } from 'react-bootstrap-typeahead';
import 'react-bootstrap-typeahead/css/Typeahead.css';
import toastr from 'toastr';
import { MEDICAL_PROCEDURE, PROCEDURE } from './constants';
import 'toastr/build/toastr.min.css';

export default class SaveAppointmentPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dob: new Date(),
      appointmentDate: new Date(),
      selected: [],
      scanAmount: '',
      maxDiscount: '',
      medicalTreatment: [],
      salutation: 'Mr',
      patientName: '',
      gender: 'Male',
      age: '',
      phoneNumber: '',
      streetAddress: '',
      streetAddress2: '',
      city: '',
      province: '',
      country: '',
      postalCode: ''
    };
    this.handleDateChange = this.handleDateChange.bind(this);
    this.onSuggestionChange = this.onSuggestionChange.bind(this);
    this.addTreatment = this.addTreatment.bind(this);
    this.onDiscountChange = this.onDiscountChange.bind(this);
  }

  onSuggestionChange = (selected) => {
    let {
      scanAmount, maxDiscount
    } = this.state;
    const medicalProcedure = Object.keys(MEDICAL_PROCEDURE).map((i) => MEDICAL_PROCEDURE[i]);
    const treatment = medicalProcedure.filter(
      (medical) => medical.procedure === selected[0]
    );

    if (treatment.length > 0) {
      scanAmount = treatment[0].amount;
      // eslint-disable-next-line prefer-destructuring
      maxDiscount = treatment[0].maxDiscount;
    }

    this.setState({ selected, scanAmount, maxDiscount });
  }

  onDiscountChange = (discount) => {
    const { maxDiscount } = this.state;
    if (discount > maxDiscount) {
      this.setState({ discount: null }, () => toastr.error('Exists the maximum discount limit.', 'Invalid!'));
    } else {
      this.setState({ discount });
    }
  }

  onSalutationChange = (salutation) => {
    let {
      gender
    } = this.state;
    if (salutation === 'Mr') {
      gender = 'Male';
    } else {
      gender = 'Female';
    }
    this.setState({ salutation, gender });
  }

  onValueChange = (value, field) => {
    this.setState({ [field]: value });
  }

  handleDateChange = (field, date) => {
    if (field === 'dob') {
      let { age } = this.state;
      const d1 = date;
      const d2 = new Date();
      const diff = d2.getTime() - d1.getTime();
      age = Math.floor(diff / (1000 * 60 * 60 * 24 * 365.25));
      this.setState({
        dob: date,
        age
      });
    } else {
      this.setState({
        appointmentDate: date
      });
    }
  };

  addTreatment = () => {
    const {
      medicalTreatment, scanAmount, selected, discount
    } = this.state;

    const actualAmount = scanAmount;
    const discountAmount = Number(discount) / 100;
    const totalAmount = actualAmount - (actualAmount * discountAmount);

    if (selected[0] !== 'GLUCOSE FASTING') {
      const procedure = Object.keys(PROCEDURE).map((i) => PROCEDURE[i]);
      const treatment = procedure.filter(
        (medical) => selected[0].indexOf(medical.procedureType) !== -1
      );

      const medicalRecords = Object.keys(medicalTreatment).map((i) => medicalTreatment[i]);
      const records = medicalRecords.filter(
        (record) => record.scanName.indexOf(treatment[0].procedureType) !== -1
      );

      if (records.length >= treatment[0].maxSlot) {
        toastr.error(`In a day only ${treatment[0].maxSlot} ${treatment[0].procedureType} based studies are allowed.`, 'Error!');
      } else {
        medicalTreatment.push(
          {
            scanName: selected[0],
            scanAmount,
            discount,
            total: totalAmount
          }
        );
        this.setState({ medicalTreatment });
      }
    } else {
      medicalTreatment.push(
        {
          scanName: selected[0],
          scanAmount,
          discount,
          total: totalAmount
        }
      );
      this.setState({ medicalTreatment });
    }
  }

  mySubmitHandler = () => {
    console.log('Form Output >>', this.state);
  }

  render() {
    const {
      dob, appointmentDate, scanAmount, maxDiscount, medicalTreatment,
      salutation, patientName, gender, age, phoneNumber, streetAddress,
      streetAddress2, city, province, country, postalCode
    } = this.state;
    const options = [
      'CT BRAIN', 'MRI BRAIN', 'GLUCOSE FASTING'
    ];
    return (
      <div className="save-page">
        <Helmet>
          <title>Save Appointment Page</title>
          <meta
            name="description"
            content="Save Appointment page of Patient's Inventory application"
          />
        </Helmet>
        <form onSubmit={this.mySubmitHandler}>
          <h1>Save Appointment</h1>
          <div className="row">
            <div className="col-2">
              <label className="label-text">
                Patient Name
              </label>
            </div>
            <div className="col-auto">
              <select className="form-control select-input" id="salutation" onChange={(e) => this.onSalutationChange(e.target.value)} value={salutation}>
                <option value="Mr">Mr</option>
                <option value="Mrs">Mrs</option>
              </select>
            </div>
            <div className="col-3">
              <input required type="text" className="form-control search-input" value={patientName} onChange={(e) => this.onValueChange(e.target.value, 'patientName')} />
            </div>
            <div className="col-auto">
              <label className="label-text">
                Gender
              </label>
            </div>
            <div className="col">
              <div className="row">
                <div className="col-auto">
                  <div className="form-check">
                    <input className="form-check-input" type="radio" name="gender" id="male" value="Male" checked={gender === 'Male'} onChange={(e) => this.onValueChange(e.target.value, 'gender')} />
                    <label className="form-check-label label-text" htmlFor="male">
                      Male
                    </label>
                  </div>
                </div>
                <div className="col-auto">
                  <div className="form-check">
                    <input className="form-check-input" type="radio" name="gender" id="female" value="Female" checked={gender === 'Female'} onChange={(e) => this.onValueChange(e.target.value, 'gender')} />
                    <label className="form-check-label label-text" htmlFor="female">
                      Female
                    </label>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-2">
              <label htmlFor="dob" className="label-text">
                DOB
              </label>
            </div>
            <div className="col-4">
              <DatePicker id="dob" className="form-control custom-input" selected={dob} dateFormat="dd MMM yyyy" onChange={this.handleDateChange.bind(this, 'dob')} />
            </div>
            <div className="col-auto">
              <label htmlFor="age" className="label-text">
                Age
              </label>
            </div>
            <div className="col-auto">
              <div className="row">
                <div className="col-6">
                  <input required type="number" className="form-control" min="1" step="1" value={age} onChange={(e) => this.onValueChange(e.target.value, 'age')} />
                </div>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-2">
              <label htmlFor="appointmentDate" className="label-text">
                Appointment Date
              </label>
            </div>
            <div className="col-4">
              <DatePicker id="appointmentDate" className="form-control custom-input" selected={appointmentDate} dateFormat="dd MMM yyyy" onChange={this.handleDateChange.bind(this, 'appointmentDate')} />
            </div>
            <div className="col-auto">
              <label htmlFor="phoneNumber" className="label-text">
                Phone Number
              </label>
            </div>
            <div className="col-4">
              <input required type="number" className="form-control custom-input" value={phoneNumber} onChange={(e) => this.onValueChange(e.target.value, 'phoneNumber')} />
            </div>
          </div>
          <div className="row">
            <div className="col-2">
              <label htmlFor="streetAddress" className="label-text">
                Address
              </label>
            </div>
            <div className="col">
              <input required type="text" id="streetAddress" placeholder="Street Address" className="form-control custom-input" value={streetAddress} onChange={(e) => this.onValueChange(e.target.value, 'streetAddress')} />
            </div>
          </div>
          <div className="row">
            <div className="col-2">&nbsp;</div>
            <div className="col">
              <input required type="text" id="streetAddress2" placeholder="Street Address 2" className="form-control custom-input" value={streetAddress2} onChange={(e) => this.onValueChange(e.target.value, 'streetAddress2')} />
            </div>
          </div>
          <div className="row">
            <div className="col-2">&nbsp;</div>
            <div className="col-auto">
              <input required type="text" id="city" placeholder="City" className="form-control" value={city} onChange={(e) => this.onValueChange(e.target.value, 'city')} />
            </div>
            <div className="col-auto">
              <input required type="text" id="state" placeholder="State / Province" className="form-control" value={province} onChange={(e) => this.onValueChange(e.target.value, 'province')} />
            </div>
          </div>
          <div className="row">
            <div className="col-2">&nbsp;</div>
            <div className="col-auto">
              <input type="text" id="postal" placeholder="Postal / Zip code" className="form-control" value={postalCode} onChange={(e) => this.onValueChange(e.target.value, 'postalCode')} />
            </div>
            <div className="col-4">
              <select className="form-control select-input-sm" id="country" value={country} onChange={(e) => this.onValueChange(e.target.value, 'country')}>
                <option value="India">India</option>
                <option value="USA">USA</option>
                <option value="UK">UK</option>
              </select>
            </div>
          </div>
          <h1>Medical Scan Details</h1>
          <div className="row">
            <div className="col-auto">
              <label htmlFor="scanList" className="label-text">
              Scan List
              </label>
            </div>
            <div className="col-3">
              <Typeahead
                id="scanList"
                onChange={(selected) => this.onSuggestionChange(selected)}
                options={options}
                selected={this.state.selected}
              />
            </div>
            <div className="col-2">
              <label className="label-text">
              Scan Amount
              </label>
            </div>
            <div className="col-2">
              <label className="label-text">
                {scanAmount}
              </label>
            </div>
            <div className="col">
              <div className="row">
                <div className="col-4">
                  <label htmlFor="status" className="label-text">
                  Discount
                  </label>
                </div>
                <div className="col-8">
                  <div className="input-group">
                    <input type="number" className="form-control custom-input" min="0" max={maxDiscount} onChange={(e) => this.onDiscountChange(e.target.value)} />
                    <div className="input-group-append">
                      <button className="btn btn-secondary search-btn" type="button" onClick={this.addTreatment}>Add</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <table className="table table-hover table-sm">
            <thead>
              <tr className="table-primary">
                <th scope="col">#</th>
                <th scope="col">Scan Name</th>
                <th scope="col">Scan Amount</th>
                <th scope="col">Discount</th>
                <th scope="col">Total Amount</th>
              </tr>
            </thead>
            <tbody>
              { medicalTreatment.length > 0 && medicalTreatment.map((treatment, index) => (
                <tr key={index}>
                  <th scope="row">{index + 1}</th>
                  <td>{treatment.scanName}</td>
                  <td>{treatment.scanAmount} INR</td>
                  <td>{treatment.discount}%</td>
                  <td>{treatment.total} INR</td>
                </tr>
              ))}

              { medicalTreatment.length === 0
              && (
                <tr>
                  <th scope="row" colSpan="5" style={{ textAlign: 'center' }}>No Record Found!</th>
                </tr>
              )
              }
            </tbody>
          </table>
          <div className="row">
            <div className="col align-center">
              <input type="submit" className="btn btn-primary save-btn" value="Save" />
            </div>
          </div>
        </form>
      </div>
    );
  }
}
