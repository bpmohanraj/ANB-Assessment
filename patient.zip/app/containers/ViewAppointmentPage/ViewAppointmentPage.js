/*
 * View Appointment Page
 *
 * List all the appointment details
 */
import React from 'react';
import { Helmet } from 'react-helmet';
import './style.scss';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch } from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router-dom';
import { VIEW_DATA } from './constants';

export default class ViewAppointmentPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fromDate: new Date(),
      toDate: new Date(),
      status: '',
      data: []
    };
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange = (field, date) => {
    const viewData = Object.keys(VIEW_DATA).map((i) => VIEW_DATA[i]);
    let data = viewData;
    if (field === 'fromDate') {
      data = viewData.filter(
        (record) => {
          const dateVal = record.appointmentDate.split('-');
          const q = new Date(`${dateVal[2]}-${dateVal[1]}-${dateVal[0]}`);
          const m = q.getMonth();
          const d = q.getDate();
          const y = q.getFullYear();
          const date1 = new Date(y, m, d);
          const date2 = this.state.toDate;
          if (date1 <= date2 && date <= date1) {
            return record;
          }
        }
      );
      this.setState({
        fromDate: date, data
      });
    } else {
      data = viewData.filter(
        (record) => {
          const dateVal = record.appointmentDate.split('-');
          const q = new Date(`${dateVal[2]}-${dateVal[1]}-${dateVal[0]}`);
          const m = q.getMonth();
          const d = q.getDate();
          const y = q.getFullYear();
          const date1 = new Date(y, m, d);
          const date2 = this.state.fromDate;
          if (date1 >= date2 && date >= date1) {
            return record;
          }
        }
      );
      this.setState({
        toDate: date, data
      });
    }
  };

  onStatusChange = (status) => {
    const viewData = Object.keys(VIEW_DATA).map((i) => VIEW_DATA[i]);
    let { data } = this.state;
    if (status !== 'All') {
      data = viewData.filter(
        (record) => record.paymentStatus === status
      );
    } else {
      data = viewData;
    }
    this.setState({ data, status });
  }

  render() {
    const {
      fromDate, toDate, status
    } = this.state;

    let { data } = this.state;

    if (data.length === 0) {
      data = Object.keys(VIEW_DATA).map((i) => VIEW_DATA[i]);
    }

    return (
      <div className="view-page">
        <Helmet>
          <title>View Appointment Page</title>
          <meta
            name="description"
            content="View Appointment page of Patient's Inventory application"
          />
        </Helmet>
        <h1>View Appointment</h1>
        <div className="row">
          <div className="col">
            <label htmlFor="fromDate" className="label-text">
              From Date:
              <DatePicker id="fromDate" className="form-control custom-input" selected={fromDate} dateFormat="dd MMM yyyy" onChange={this.handleChange.bind(this, 'fromDate')} />
            </label>
          </div>
          <div className="col">
            <label htmlFor="toDate" className="label-text">
              To Date:
              <DatePicker name="toDate" className="form-control custom-input" selected={toDate} dateFormat="dd MMM yyyy" onChange={this.handleChange.bind(this, 'toDate')} />
            </label>
          </div>
          <div className="col">
            <label htmlFor="status" className="label-text">
              Status:
              <select className="form-control select-input" id="status" value={status} onChange={(e) => this.onStatusChange(e.target.value)}>
                <option value="All">All</option>
                <option value="Due">Due</option>
                <option value="Paid">Paid</option>
              </select>
            </label>
          </div>
          <div className="col-auto">
            <label htmlFor="status" className="label-text">
              Search:
              <div className="input-group">
                <input type="text" className="form-control search-input" placeholder="Search" />
                <div className="input-group-append">
                  <button className="btn btn-secondary search-btn" type="button">
                    <FontAwesomeIcon icon={faSearch} />
                  </button>
                </div>
              </div>
            </label>
          </div>
        </div>
        <table className="table table-hover table-sm">
          <thead>
            <tr className="table-primary">
              <th scope="col">#</th>
              <th scope="col">Patient Name</th>
              <th scope="col">Age-Gender</th>
              <th scope="col">Appointment Date</th>
              <th scope="col">Balanced Amount</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            {data.length > 0 && data.map((patient, index) => (
              <tr key={index} className={patient.paymentStatus === 'Due' ? 'red-bg' : 'green-bg'}>
                <th scope="row">{index + 1}</th>
                <td>{patient.patientName}</td>
                <td>{patient.age} {patient.gender}</td>
                <td>{patient.appointmentDate}</td>
                <td>{patient.balanceAmount} INR</td>
                <td>
                  {patient.paymentStatus === 'Due' && (
                    <Link to={`/billing/${index}`}>Click to Pay</Link>
                  ) }
                </td>
              </tr>
            ))}

            {data.length === 0
              && (
                <tr>
                  <th scope="row" colSpan="6" style={{ textAlign: 'center' }}>No Record Found!</th>
                </tr>
              )
            }
          </tbody>
        </table>
      </div>
    );
  }
}
