/*
 * AppConstants
 * Each action has a corresponding type, which the reducer knows and picks up on.
 * To avoid weird typos between the reducer and the actions, we save them as
 * constants here. We prefix them with 'yourproject/YourComponent' so we avoid
 * reducers accidentally picking up actions they shouldn't.
 *
 * Follow this format:
 * export const YOUR_ACTION_CONSTANT = 'yourproject/YourContainer/YOUR_ACTION_CONSTANT';
 */

export const VIEW_DATA = [
  {
    patientName: 'Hari Haran', age: 27, gender: 'Male', appointmentDate: '12-Feb-2020', balanceAmount: 230, paymentStatus: 'Due'
  },
  {
    patientName: 'Siva Shankar', age: 23, gender: 'Male', appointmentDate: '13-Feb-2020', balanceAmount: 0, paymentStatus: 'Paid'
  },
  {
    patientName: 'Ravi Chandran', age: 25, gender: 'Male', appointmentDate: '14-Feb-2020', balanceAmount: 0, paymentStatus: 'Paid'
  }
];
