module.exports = 'IMAGE_MOCK';
